package com.luminar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringbootAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
